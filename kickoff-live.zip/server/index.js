/**
 * KickOff Live — Backend Server
 * Express + Socket.io + API-Football
 *
 * HOW IT WORKS:
 *  1. On startup, fetches today's fixtures for all configured leagues
 *  2. Every REFRESH_INTERVAL ms, re-fetches live + today's matches
 *  3. Broadcasts updated data to all connected browsers via Socket.io
 *  4. Browser receives updates instantly without refreshing the page
 */

require("dotenv").config();
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const axios = require("axios");
const cors = require("cors");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

// ─── API CONFIG ────────────────────────────────────────────────────────────────
const API_KEY = process.env.API_FOOTBALL_KEY;
const REFRESH_INTERVAL = parseInt(process.env.REFRESH_INTERVAL || "60000");
const PORT = process.env.PORT || 3000;

const apiClient = axios.create({
  baseURL: "https://v3.football.api-sports.io",
  headers: {
    "x-apisports-key": API_KEY,
  },
  timeout: 10000,
});

// ─── LEAGUE IDs (API-Football league IDs) ─────────────────────────────────────
// Find more at: https://www.api-football.com/documentation-v3#tag/Leagues
const LEAGUES = [
  // South Africa
  { id: 288, name: "PSL",              flag: "🇿🇦", country: "South Africa",   group: "south-africa" },
  { id: 672, name: "Nedbank Cup",      flag: "🇿🇦", country: "South Africa",   group: "south-africa" },
  // Africa
  { id: 6,   name: "AFCON",            flag: "🌍", country: "Africa",          group: "africa" },
  { id: 29,  name: "AFCON Qualifying", flag: "🌍", country: "Africa",          group: "africa" },
  // Europe - Top 5 + UCL
  { id: 39,  name: "Premier League",   flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", country: "England",        group: "europe" },
  { id: 2,   name: "Champions League", flag: "🏆", country: "Europe",          group: "europe" },
  { id: 140, name: "La Liga",          flag: "🇪🇸", country: "Spain",           group: "europe" },
  { id: 78,  name: "Bundesliga",       flag: "🇩🇪", country: "Germany",         group: "europe" },
  { id: 135, name: "Serie A",          flag: "🇮🇹", country: "Italy",           group: "europe" },
  { id: 61,  name: "Ligue 1",          flag: "🇫🇷", country: "France",          group: "europe" },
];

// ─── IN-MEMORY CACHE ───────────────────────────────────────────────────────────
let cache = {
  matches: {},       // { leagueId: [match, ...] }
  standings: {},     // { leagueId: [team, ...] }
  lastUpdated: null,
  apiCallsToday: 0,
};

// ─── FETCH: TODAY'S FIXTURES ───────────────────────────────────────────────────
async function fetchFixtures(leagueId) {
  try {
    const today = new Date().toISOString().split("T")[0]; // YYYY-MM-DD
    const res = await apiClient.get("/fixtures", {
      params: {
        league: leagueId,
        date: today,
        timezone: "Africa/Johannesburg",
      },
    });
    cache.apiCallsToday++;
    return res.data.response || [];
  } catch (err) {
    console.error(`[API] Failed to fetch fixtures for league ${leagueId}:`, err.message);
    return [];
  }
}

// ─── FETCH: LIVE FIXTURES ONLY ─────────────────────────────────────────────────
async function fetchLiveFixtures() {
  try {
    const leagueIds = LEAGUES.map((l) => l.id).join("-");
    const res = await apiClient.get("/fixtures", {
      params: { live: leagueIds },
    });
    cache.apiCallsToday++;
    return res.data.response || [];
  } catch (err) {
    console.error("[API] Failed to fetch live fixtures:", err.message);
    return [];
  }
}

// ─── FETCH: STANDINGS ──────────────────────────────────────────────────────────
async function fetchStandings(leagueId, season) {
  try {
    const res = await apiClient.get("/standings", {
      params: { league: leagueId, season },
    });
    cache.apiCallsToday++;
    const data = res.data.response?.[0]?.league?.standings?.[0] || [];
    return data.slice(0, 20).map((t) => ({
      pos: t.rank,
      team: t.team.name,
      badge: t.team.logo,
      p: t.all.played,
      w: t.all.win,
      d: t.all.draw,
      l: t.all.lose,
      gd: t.goalsDiff > 0 ? `+${t.goalsDiff}` : `${t.goalsDiff}`,
      pts: t.points,
      form: t.form,
    }));
  } catch (err) {
    console.error(`[API] Failed to fetch standings for league ${leagueId}:`, err.message);
    return [];
  }
}

// ─── TRANSFORM: RAW API → CLEAN MATCH OBJECT ──────────────────────────────────
function transformFixture(fixture) {
  const f = fixture.fixture;
  const teams = fixture.teams;
  const goals = fixture.goals;
  const score = fixture.score;
  const league = fixture.league;

  // Determine status
  const statusShort = f.status.short; // NS, 1H, HT, 2H, ET, P, FT, AET, PEN, SUSP, INT, PST, CANC, ABD, AWD, WO
  let status = "ns";
  let displayMin = "";

  if (["NS", "TBD"].includes(statusShort)) {
    status = "ns";
    const kickoff = new Date(f.date);
    displayMin = kickoff.toLocaleTimeString("en-ZA", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
      timeZone: "Africa/Johannesburg",
    });
  } else if (statusShort === "HT") {
    status = "ht";
    displayMin = "HT";
  } else if (["1H", "2H", "ET", "P", "LIVE"].includes(statusShort)) {
    status = "live";
    displayMin = f.status.elapsed || "?";
  } else if (["FT", "AET", "PEN"].includes(statusShort)) {
    status = "ft";
    displayMin = statusShort === "FT" ? "FT" : statusShort;
  } else {
    status = "postponed";
    displayMin = statusShort;
  }

  return {
    id: f.id,
    leagueId: league.id,
    leagueName: league.name,
    leagueFlag: LEAGUES.find((l) => l.id === league.id)?.flag || "⚽",
    round: league.round,
    home: teams.home.name,
    homeBadge: teams.home.logo,
    homeId: teams.home.id,
    away: teams.away.name,
    awayBadge: teams.away.logo,
    awayId: teams.away.id,
    hs: goals.home,
    as: goals.away,
    min: displayMin,
    status,
    venue: f.venue?.name,
    city: f.venue?.city,
    referee: f.referee,
    elapsed: f.status.elapsed,
  };
}

// ─── MAIN DATA REFRESH CYCLE ───────────────────────────────────────────────────
async function refreshData(liveOnly = false) {
  console.log(`[${new Date().toISOString()}] Refreshing data (liveOnly=${liveOnly})...`);

  if (liveOnly) {
    // Efficient: only update matches that are currently live
    const liveFixtures = await fetchLiveFixtures();
    liveFixtures.forEach((f) => {
      const match = transformFixture(f);
      const lid = match.leagueId;
      if (cache.matches[lid]) {
        const idx = cache.matches[lid].findIndex((m) => m.id === match.id);
        if (idx !== -1) cache.matches[lid][idx] = match;
      }
    });
  } else {
    // Full refresh: fetch all leagues
    const season = new Date().getFullYear();
    const allFixtures = [];

    for (const league of LEAGUES) {
      const fixtures = await fetchFixtures(league.id);
      const transformed = fixtures.map(transformFixture);
      cache.matches[league.id] = transformed;
      allFixtures.push(...transformed);

      // Small delay to avoid rate limiting on free tier
      await new Promise((r) => setTimeout(r, 200));
    }

    // Fetch standings for key leagues (PSL + EPL) — these change slowly
    cache.standings[288] = await fetchStandings(288, season); // PSL
    cache.standings[39]  = await fetchStandings(39,  season); // EPL
    cache.standings[140] = await fetchStandings(140, season); // La Liga
  }

  cache.lastUpdated = new Date().toISOString();

  // Broadcast to all connected browsers
  io.emit("update", {
    matches: cache.matches,
    standings: cache.standings,
    lastUpdated: cache.lastUpdated,
    apiCallsToday: cache.apiCallsToday,
  });

  const liveCount = Object.values(cache.matches)
    .flat()
    .filter((m) => m.status === "live").length;
  console.log(`[OK] Broadcast sent. Live matches: ${liveCount}. API calls today: ${cache.apiCallsToday}`);
}

// ─── SMART REFRESH SCHEDULE ────────────────────────────────────────────────────
// Full refresh every 15 minutes. Live-only update every 60 seconds when live matches exist.
function startRefreshSchedule() {
  // Initial full load
  refreshData(false);

  // Full refresh every 15 minutes
  setInterval(() => refreshData(false), 15 * 60 * 1000);

  // Live-only refresh every 60 seconds (cheap: single API call)
  setInterval(() => {
    const hasLive = Object.values(cache.matches).flat().some((m) => m.status === "live");
    if (hasLive) refreshData(true);
  }, REFRESH_INTERVAL);
}

// ─── REST ENDPOINTS ────────────────────────────────────────────────────────────
// Used as fallback / initial page load before Socket.io connects
app.get("/api/matches", (req, res) => {
  res.json({
    matches: cache.matches,
    standings: cache.standings,
    lastUpdated: cache.lastUpdated,
    leagues: LEAGUES,
  });
});

app.get("/api/fixtures/:id", async (req, res) => {
  try {
    const result = await apiClient.get("/fixtures", {
      params: { id: req.params.id },
    });
    res.json(result.data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    lastUpdated: cache.lastUpdated,
    apiCallsToday: cache.apiCallsToday,
    liveMatches: Object.values(cache.matches).flat().filter((m) => m.status === "live").length,
    hasApiKey: !!API_KEY && API_KEY !== "your_api_key_here",
  });
});

// ─── SOCKET.IO ─────────────────────────────────────────────────────────────────
io.on("connection", (socket) => {
  console.log(`[WS] Client connected: ${socket.id}`);

  // Send cached data immediately on connect (no waiting for next refresh cycle)
  socket.emit("update", {
    matches: cache.matches,
    standings: cache.standings,
    lastUpdated: cache.lastUpdated,
    leagues: LEAGUES,
  });

  socket.on("disconnect", () => {
    console.log(`[WS] Client disconnected: ${socket.id}`);
  });
});

// ─── START ─────────────────────────────────────────────────────────────────────
server.listen(PORT, () => {
  if (!API_KEY || API_KEY === "your_api_key_here") {
    console.warn("\n⚠️  WARNING: No API key set!");
    console.warn("   Copy .env.example to .env and add your API-Football key.");
    console.warn("   Get a free key at: https://www.api-football.com\n");
  } else {
    console.log(`\n✅ KickOff Live server running on http://localhost:${PORT}`);
    console.log(`   API key: ${API_KEY.slice(0, 8)}...`);
    console.log(`   Refresh interval: ${REFRESH_INTERVAL / 1000}s\n`);
    startRefreshSchedule();
  }
});
